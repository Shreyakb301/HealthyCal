import { useEffect, useMemo, useRef, useState } from "react";
import "./css/style.css";

const API_BASE = "";

function Header() {
  return (
    <header>
      <h1>HealthyCal</h1>
      <nav>
        <a href="/">Home</a>
        <a href="/about.html">About</a>
        <a href="https://www.choosemyplate.gov/" target="_blank" rel="noopener">Nutrition Guide</a>
      </nav>
    </header>
  );
}

const TIPS = [
  "Drink a glass of water before meals to aid digestion.",
  "Portion your snacks instead of eating straight from the bag.",
  "Add more color to your plate with fruits and vegetables!",
  "Track your calories to stay mindful of energy balance.",
  "Even healthy food contributes to calories — stay aware!",
];
function DailyTip() {
  const [show, setShow] = useState(false);
  const [tip, setTip] = useState("");
  const handleClick = () => {
    const random = TIPS[Math.floor(Math.random() * TIPS.length)];
    setTip(random);
    setShow((s) => !s);
  };
  return (
    <section id="daily-tip">
      <button id="tipBtn" onClick={handleClick}>Show Daily Tip</button>
      <p id="tipText" style={{ display: show ? "block" : "none" }}>{tip}</p>
    </section>
  );
}

function NutritionSearch() {
  const [val, setVal] = useState("");
  const [msg, setMsg] = useState("");
  const onSearch = () => {
    if (!val.trim()) {
      setMsg("Please enter a food name.");
      return;
    }
    localStorage.setItem("lastSearch", val.trim());
    setMsg(`Searching nutrition for: ${val.trim()} ...`);
  };
  return (
    <section id="nutrition-search">
      <h2>Check Nutrition Facts</h2>
      <input
        type="text"
        id="foodInput"
        placeholder="Enter a food (e.g., banana)"
        value={val}
        onChange={(e) => setVal(e.target.value)}
      />
      <button id="searchBtn" onClick={onSearch}>Get Nutrition Info</button>
      <div id="nutritionResult">{msg}</div>
    </section>
  );
}

function useApi() {
  const tokenKey = "healthycal_token";
  const getToken = () => localStorage.getItem(tokenKey);
  const setToken = (t) => localStorage.setItem(tokenKey, t);
  const api = async (route, opts = {}) => {
    const headers = { "Content-Type": "application/json", ...(opts.headers || {}) };
    const t = getToken();
    if (t) headers.Authorization = `Bearer ${t}`;
    const res = await fetch(API_BASE + route, { ...opts, headers });
    if (!res.ok) {
      let msg = "Request failed";
      try { const err = await res.json(); msg = err.error || msg; } catch {}
      throw new Error(msg);
    }
    const ct = res.headers.get("content-type") || "";
    return ct.includes("application/json") ? res.json() : res.text();
  };
  return useMemo(() => ({ api, getToken, setToken }), []);
}

function InlineLogin({ onLoggedIn }) {
  const { api, setToken } = useApi();
  const [msg, setMsg] = useState("");
  const userRef = useRef(null);
  const passRef = useRef(null);
  const login = async () => {
    setMsg("");
    try {
      const body = {
        username: (userRef.current?.value || "demo").trim(),
        password: passRef.current?.value || "demo123",
      };
      const res = await api("/api/login", { method: "POST", body: JSON.stringify(body) });
      setToken(res.token);
      setMsg(`Welcome, ${res.username}!`);
      onLoggedIn?.();
    } catch (e) { setMsg(e.message); }
  };
  return (
    <>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr auto", gap: ".5rem", marginBottom: ".5rem" }}>
        <input ref={userRef} type="text" placeholder="Username (demo)" />
        <input ref={passRef} type="password" placeholder="Password (demo123)" />
        <button onClick={login}>Login</button>
      </div>
      <p id="authMsg" style={{ marginTop: 0 }}>{msg}</p>
    </>
  );
}

function MealForm({ onSaved }) {
  const { api } = useApi();
  const foodRef = useRef(null);
  const portionRef = useRef(null);
  const calRef = useRef(null);
  const submit = async (e) => {
    e.preventDefault();
    const food = foodRef.current?.value.trim();
    const portion = portionRef.current?.value.trim();
    const calories = Number(calRef.current?.value);
    if (!food || !portion || Number.isNaN(calories)) { alert("Please fill out food, portion, and calories."); return; }
    try {
      await api("/api/meals", { method: "POST", body: JSON.stringify({ food, portion, calories }) });
      if (foodRef.current) foodRef.current.value = "";
      if (portionRef.current) portionRef.current.value = "";
      if (calRef.current) calRef.current.value = "";
      onSaved?.();
    } catch (e) { alert(e.message); }
  };
  return (
    <form id="mealForm" onSubmit={submit}>
      <label htmlFor="food">Food Name:</label>
      <input type="text" id="food" name="food" placeholder="e.g., Oatmeal" ref={foodRef} />
      <label htmlFor="amount">Portion:</label>
      <input type="text" id="amount" name="amount" placeholder="e.g., 1 cup" ref={portionRef} />
      <label htmlFor="calories">Calories:</label>
      <input type="number" id="calories" name="calories" min="0" placeholder="e.g., 150" ref={calRef} />
      <input type="submit" value="Add Meal" />
    </form>
  );
}

function MealsList({ reloadKey }) {
  const { api } = useApi();
  const [meals, setMeals] = useState(null);
  const load = async () => {
    try { setMeals(await api("/api/meals")); }
    catch { setMeals([]); }
  };
  useEffect(() => { load(); }, [reloadKey]);
  return (
    <>
      <h2>Your Meals</h2>
      <div id="mealsList" style={{ marginTop: ".75rem" }}>
        {meals === null ? <em>Loading…</em> : meals.length === 0 ? <em>No meals yet.</em> :
          meals.map((m) => (
            <div key={m.id} style={{ border: "1px solid #ddd", padding: ".5rem .75rem", margin: ".5rem 0", borderRadius: 8 }}>
              {m.food} — {m.portion} — {m.calories} kcal
            </div>
          ))
        }
      </div>
    </>
  );
}

export default function App() {
  const [reloadKey, setReloadKey] = useState(0);
  const triggerReload = () => setReloadKey((k) => k + 1);
  return (
    <>
      <Header />
      <main>
        <section>
          <h2>Welcome</h2>
          <p>HealthyCal helps you stay mindful of calories, even when choosing healthy foods.</p>
          <img src="/images/homepage.jpeg" alt="A bowl of healthy food with vegetables and grains" width="500" />
        </section>
        <DailyTip />
        <NutritionSearch />
        <h2>Log a Meal</h2>
        <InlineLogin onLoggedIn={triggerReload} />
        <MealForm onSaved={triggerReload} />
        <MealsList reloadKey={reloadKey} />
      </main>
    </>
  );
}
