# Backend Features (HW5)

1) **Serve Files to Client**
   - Express serves the `backend/public/` directory at `/`.

2) **Save and Load Files on Server Filesystem**
   - Meals persisted in `backend/data/meals.json`.
   - Endpoints:
     - `GET /api/meals` – returns saved meals
     - `POST /api/meals` – adds a meal

3) **Authenticate Requests (JWT)**
   - `POST /api/login` verifies credentials and returns a JWT (2h expiry).
   - Protected routes require `Authorization: Bearer <token>`.
