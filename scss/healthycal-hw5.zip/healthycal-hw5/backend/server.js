import express from "express";
import cors from "cors";
import jwt from "jsonwebtoken";
import { promises as fs } from "fs";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = 3000;
const JWT_SECRET = "change-this-before-submitting";

const DATA_DIR = path.join(__dirname, "data");
const MEALS_FILE = path.join(DATA_DIR, "meals.json");
const USERS_FILE = path.join(DATA_DIR, "users.json");
const PUBLIC_DIR = path.join(__dirname, "public");

const app = express();
app.use(cors({ origin: "*" }));
app.use(express.json());

async function ensureFiles() {
  await fs.mkdir(DATA_DIR, { recursive: true }).catch(() => {});
  try { await fs.access(MEALS_FILE); }
  catch { await fs.writeFile(MEALS_FILE, JSON.stringify({ meals: [] }, null, 2)); }
  try { await fs.access(USERS_FILE); }
  catch {
    await fs.writeFile(USERS_FILE, JSON.stringify({ users: [{ id: "u1", username: "demo", password: "demo123" }] }, null, 2));
  }
}
async function readJSON(p) { return JSON.parse(await fs.readFile(p, "utf-8")); }
async function writeJSON(p, d) { await fs.writeFile(p, JSON.stringify(d, null, 2)); }

function authRequired(req, res, next) {
  const hdr = req.headers.authorization || "";
  const token = hdr.startsWith("Bearer ") ? hdr.slice(7) : null;
  if (!token) return res.status(401).json({ error: "Missing token" });
  try {
    req.user = jwt.verify(token, JWT_SECRET);
    next();
  } catch {
    res.status(401).json({ error: "Invalid or expired token" });
  }
}

// minimal API
app.get("/api/health", (req, res) => res.json({ ok: true }));

app.post("/api/login", async (req, res) => {
  const { username, password } = req.body || {};
  if (!username || !password) return res.status(400).json({ error: "username & password required" });
  const db = await readJSON(USERS_FILE);
  const user = db.users.find(u => u.username === username && u.password === password);
  if (!user) return res.status(401).json({ error: "invalid credentials" });
  const token = jwt.sign({ sub: user.id, username: user.username }, JWT_SECRET, { expiresIn: "2h" });
  res.json({ token, username: user.username });
});

app.get("/api/meals", authRequired, async (req, res) => {
  const db = await readJSON(MEALS_FILE);
  res.json(db.meals);
});

app.post("/api/meals", authRequired, async (req, res) => {
  const { food, portion, calories } = req.body || {};
  if (!food || !portion || typeof calories !== "number") {
    return res.status(400).json({ error: "food, portion, calories(number) required" });
  }
  const db = await readJSON(MEALS_FILE);
  const meal = {
    id: "m" + Math.random().toString(36).slice(2, 9),
    food, portion, calories,
    createdAt: new Date().toISOString()
  };
  db.meals.push(meal);
  await writeJSON(MEALS_FILE, db);
  res.status(201).json(meal);
});

// serve static (React build and any static pages)
app.use(express.static(PUBLIC_DIR));
app.get("*", (req, res) => res.sendFile(path.join(PUBLIC_DIR, "index.html")));

await ensureFiles();
app.listen(PORT, () => console.log("HealthyCal backend at http://localhost:" + PORT));
