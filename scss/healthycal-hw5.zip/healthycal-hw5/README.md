# HealthyCal HW5 (Combined Project)

## Run (one-time build then start)
```bash
cd backend
npm run prep   # installs backend deps, builds React, copies build into backend/public
npm start      # starts Express on http://localhost:3000
```

### Test
- Open http://localhost:3000
- Login with **demo / demo123**
- Add meals (saved to filesystem at `backend/data/meals.json`)

### API
- `POST /api/login` -> { token }
- `GET /api/meals` (Bearer token)
- `POST /api/meals` (Bearer token, JSON: {food, portion, calories})